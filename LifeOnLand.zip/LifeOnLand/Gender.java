package LifeOnLand;

public enum Gender { MALE , FEMALE }