package LifeOnLand;
public class Person {
    public String name;
    public int age;

    //constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
// setters and getters
   
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String info() {
        return "Name: " + name + " ,Age: " + age;
    }
}