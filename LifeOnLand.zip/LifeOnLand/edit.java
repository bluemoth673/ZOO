package LifeOnLand;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.IOException;
import java.util.ArrayList;

public class edit {
	
	    private static ArrayList<Visitor> visitors = File_DataBase.loadVisitors();
	    private static ArrayList<Employee> employees = File_DataBase.loadEmployees();
	    private static ArrayList<Staff> staffMembers = File_DataBase.loadStaff();
	    private static ArrayList<Animal> animals = File_DataBase.loadAnimals();
	    
    @SuppressWarnings("unused")
	public static void main(String[] args) {
        
    	ImageIcon i = new ImageIcon("./4Biomes.webp");
    	i.setDescription("Biomes");
    	
    	// Create JFrame
        JFrame frame = new JFrame("Zoo Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage(edit.class.getResource("/LifeOnLand/4Biomes.png")));
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

        // Login Panel
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(null);
        loginPanel.setSize(screenSize.width, screenSize.height);
        loginPanel.setBackground(null);
        loginPanel.setOpaque(false); 
        
        JTextField txtUsername = new JTextField("Username");
        txtUsername.setBounds(620, 250, 150, 29);
        txtUsername.setForeground(Color.GRAY);
        txtUsername.setFont(new Font("Arial", Font.PLAIN, 16));
        txtUsername.setCaretColor(Color.BLACK);
        txtUsername.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (txtUsername.getText().equals("Username")) {
                    txtUsername.setText("");
                    txtUsername.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (txtUsername.getText().isEmpty()) {
                    txtUsername.setText("Username");
                    txtUsername.setForeground(Color.GRAY);
                }
            }
        });
        frame.setFocusable(true);
        frame.requestFocusInWindow();

        JPasswordField txtPassword = new JPasswordField("Password");
        txtPassword.setBounds(580, 300, 150, 29);
        txtPassword.setForeground(Color.GRAY);
        txtPassword.setFont(new Font("Arial", Font.PLAIN, 16));
        txtPassword.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (String.valueOf(txtPassword.getPassword()).equals("Password")) {
                    txtPassword.setText("");
                    txtPassword.setForeground(Color.BLACK);
                    txtPassword.setEchoChar('•'); // Set the echo char to hide input
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (String.valueOf(txtPassword.getPassword()).isEmpty()) {
                    txtPassword.setText("Password");
                    txtPassword.setForeground(Color.GRAY);
                    txtPassword.setEchoChar((char) 0); // Show plain text for the placeholder
                }
            }
        });
//        frame.setFocusable(true);
//        frame.requestFocusInWindow();

        JButton Toggle = new JButton("Show");
        Toggle.setBounds(730, 300, 80, 29);
        Toggle.setForeground(Color.black);
        Toggle.setBackground(Color.WHITE);
        Toggle.setFont(new Font("Arial", Font.PLAIN, 16));
        
        
        Toggle.addActionListener(new ActionListener() {
            private boolean isVisible = false; // Track visibility state

            @Override
            public void actionPerformed(ActionEvent e) {
                if (isVisible) {
                    // Mask the password and show the "closed eye" icon
                	Toggle.setText("Show");
                	txtPassword.setEchoChar('•');
                    
                } else {
                    // Unmask the password and show the "open eye" icon
                	Toggle.setText("Hide");
                	txtPassword.setEchoChar((char) 0);
                   
                }
                isVisible = !isVisible; // Toggle state
            }
        });
        
        JButton login = new JButton("Login");
        login.setBounds(650, 400, 80, 30);
        login.setForeground(Color.BLACK);
        
         
        login.setBackground(Color.WHITE);
        login.setFont(new Font("Arial", Font.PLAIN, 16));

        loginPanel.add(txtUsername);
        loginPanel.add(txtPassword);
        loginPanel.add(Toggle);
        loginPanel.add(login);
        frame.add(loginPanel);
        
        JLabel Zoo = new JLabel("Zoo");
        Zoo.setIcon(new ImageIcon("D:\\University\\AASTMT\\3rd Term\\Object Oriented Programming (OOP)\\Project\\Life on Land\\src\\LifeOnLand\\Animals.png"));
        Zoo.setSize(screenSize.width, screenSize.height);
        loginPanel.add(Zoo);
        
        JLabel Ani = new JLabel("Zoo");
        Ani.setIcon(new ImageIcon("D:\\University\\AASTMT\\3rd Term\\Object Oriented Programming (OOP)\\Project\\Life on Land\\src\\LifeOnLand\\4Biomes.png"));
        Ani.setSize(screenSize.width, screenSize.height);

        JLabel AdminImg = new JLabel("Admin");
        AdminImg.setIcon(new ImageIcon("D:\\University\\AASTMT\\3rd Term\\Object Oriented Programming (OOP)\\Project\\Life on Land\\src\\LifeOnLand\\Admin.png"));
        AdminImg.setSize(screenSize.width, screenSize.height);
        
        JLabel EMP = new JLabel("Employee");
        EMP.setIcon(new ImageIcon("D:\\University\\AASTMT\\3rd Term\\Object Oriented Programming (OOP)\\Project\\Life on Land\\src\\LifeOnLand\\Staff.png"));
        EMP.setSize(screenSize.width, screenSize.height);

        JLabel Visit = new JLabel("Visit");
        Visit.setIcon(new ImageIcon("D:\\University\\AASTMT\\3rd Term\\Object Oriented Programming (OOP)\\Project\\Life on Land\\src\\LifeOnLand\\visit.png"));
        Visit.setSize(screenSize.width, screenSize.height);
        
        
        // Admin Panel
        JPanel Admin = new JPanel();
        Admin.setLayout(null);
        Admin.setSize(screenSize.width, screenSize.height);
        
        JButton displayVisitorsButton = new JButton("Display Visitors");
        displayVisitorsButton.setBounds(400, 200, 200, 30);
        displayVisitorsButton.setForeground(Color.BLACK);
        displayVisitorsButton.setBackground(Color.WHITE);
        displayVisitorsButton.setFont(new Font("Arial", Font.PLAIN, 16));
        
        JButton displayEmployeesButton = new JButton("Display Employees");
        displayEmployeesButton.setBounds(400, 600, 200, 30);
        displayEmployeesButton.setForeground(Color.BLACK);
        displayEmployeesButton.setBackground(Color.WHITE);
        displayEmployeesButton.setFont(new Font("Arial", Font.PLAIN, 16));
        
        JButton displayStaffButton = new JButton("Display Staff");
        displayStaffButton.setBounds(800, 200, 200, 30);
        displayStaffButton.setForeground(Color.BLACK);
        displayStaffButton.setBackground(Color.WHITE);
        displayStaffButton.setFont(new Font("Arial", Font.PLAIN, 16));
        
        JButton displayAnimalsButton = new JButton("Display Animals");
        displayAnimalsButton.setBounds(800, 600, 200, 30);
        displayAnimalsButton.setForeground(Color.BLACK);
        displayAnimalsButton.setBackground(Color.WHITE);
        displayAnimalsButton.setFont(new Font("Arial", Font.PLAIN, 16));
        
        displayVisitorsButton.addActionListener(e -> displayData(visitors, "Visitors"));
        displayEmployeesButton.addActionListener(e -> displayData(employees, "Employees"));       
        displayStaffButton.addActionListener(e -> displayData(staffMembers, "Staff Members"));
        displayAnimalsButton.addActionListener(e -> displayData(animals, "Animals"));
        
        JPanel Animal = new JPanel();
        Animal.setLayout(null);
        Animal.setSize(screenSize.width, screenSize.height);
        
        JButton addAnimalsbtn = new JButton("Add Animals");
        addAnimalsbtn.setBounds(400, 300, 200, 30);
        addAnimalsbtn.setForeground(Color.BLACK);
        addAnimalsbtn.setBackground(Color.WHITE);
        addAnimalsbtn.setFont(new Font("Arial", Font.PLAIN, 16));
        
        JButton displayAnimalsbtn = new JButton("Display Animals");
        displayAnimalsbtn.setBounds(800, 300, 200, 30);
        displayAnimalsbtn.setForeground(Color.BLACK);
        displayAnimalsbtn.setBackground(Color.WHITE);
        displayAnimalsbtn.setFont(new Font("Arial", Font.PLAIN, 16));
        
        addAnimalsbtn.addActionListener(e -> addAnimal());
        displayAnimalsbtn.addActionListener(e -> displayData(animals, "Animals"));
        
        JPanel Visitor = new JPanel();
        Visitor.setLayout(null);
        Visitor.setSize(screenSize.width, screenSize.height);
        
        JButton displayVisitorsbtn = new JButton("Display Visitors");
        displayVisitorsbtn.setBounds(400, 300, 200, 30);
        displayVisitorsbtn.setForeground(Color.BLACK);
        displayVisitorsbtn.setBackground(Color.WHITE);
        displayVisitorsbtn.setFont(new Font("Arial", Font.PLAIN, 16));
        
        JButton addVisitorsbtn = new JButton("Add Visitors");
        addVisitorsbtn.setBounds(800, 300, 200, 30);
        addVisitorsbtn.setForeground(Color.BLACK);
        addVisitorsbtn.setBackground(Color.WHITE);
        addVisitorsbtn.setFont(new Font("Arial", Font.PLAIN, 16));
        
        addVisitorsbtn.addActionListener(e -> addVisitor());        
        displayVisitorsbtn.addActionListener(e -> displayData(visitors, "Visitors"));
        
        JPanel Emp = new JPanel();
        Emp.setLayout(null);
        Emp.setSize(screenSize.width, screenSize.height);
        
        JButton displayEmployeesbtn = new JButton("Display Employees");
        displayEmployeesbtn.setBounds(800, 200, 200, 30);
        displayEmployeesbtn.setForeground(Color.BLACK);
        displayEmployeesbtn.setBackground(Color.WHITE);
        displayEmployeesbtn.setFont(new Font("Arial", Font.PLAIN, 16));
        
        JButton displayStaffbtn = new JButton("Display Staff");
        displayStaffbtn.setBounds(800, 500, 200, 30);
        displayStaffbtn.setForeground(Color.BLACK);
        displayStaffbtn.setBackground(Color.WHITE);
        displayStaffbtn.setFont(new Font("Arial", Font.PLAIN, 16));
        
        JButton addEmployeeButton = new JButton("Add Employees");
        addEmployeeButton.setBounds(400, 500, 200, 30);
        addEmployeeButton.setForeground(Color.BLACK);
        addEmployeeButton.setBackground(Color.WHITE);
        addEmployeeButton.setFont(new Font("Arial", Font.PLAIN, 16));
        
        JButton addStaffButton = new JButton("Add Staff");
        addStaffButton.setBounds(400, 200, 200, 30);
        addStaffButton.setForeground(Color.BLACK);
        addStaffButton.setBackground(Color.WHITE);
        addStaffButton.setFont(new Font("Arial", Font.PLAIN, 16));
        
        addEmployeeButton.addActionListener(e -> addEmployee());
        addStaffButton.addActionListener(e -> addStaff());       
        displayEmployeesbtn.addActionListener(e -> displayData(employees, "Employees"));
        displayStaffbtn.addActionListener(e -> displayData(staffMembers, "Staff Members"));
        
        JButton back = new JButton("Back");
        back.setBounds(650, 400, 80, 30);
        back.setForeground(Color.BLACK);
        back.setBackground(Color.WHITE);
        back.setVisible(true);
        back.setFont(new Font("Arial", Font.PLAIN, 16));
        back.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		loginPanel.setVisible(true);
                Admin.setVisible(false);
                Animal.setVisible(false);
                Visitor.setVisible(false);
                Emp.setVisible(false);
        	}
        });
        
        // Switch between Login and Admin Panels
        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = txtUsername.getText();
                String password = new String(txtPassword.getPassword());

                if (username.equals("admin") && password.equals("password")) {
                    JOptionPane.showMessageDialog(null, "Logged in successfully!");
                    loginPanel.setVisible(false);
                    Admin.setVisible(true);
                    Admin.add(displayVisitorsButton);
                    Admin.add(displayEmployeesButton);
                    Admin.add(displayStaffButton);
                    Admin.add(displayAnimalsButton);
                    Admin.add(back);
                    Admin.add(AdminImg);
                    frame.add(Admin);
                }
                
                else if(username.equals("animal") && password.equals("animal")){
                	JOptionPane.showMessageDialog(null, "Logged in successfully!");
                	loginPanel.setVisible(false);
                	Animal.setVisible(true);
                	Animal.add(addAnimalsbtn);
                	Animal.add(displayAnimalsbtn);
                	Animal.add(back);
                	Animal.add(Ani);
                	frame.add(Animal);
                }
                
                else if(username.equals("visitor") && password.equals("visitor")){
                	JOptionPane.showMessageDialog(null, "Logged in successfully!");
                	loginPanel.setVisible(false);
                	Visitor.setVisible(true);
                	Visitor.add(addVisitorsbtn);
                	Visitor.add(displayVisitorsbtn);
                	Visitor.add(back);
                	Visitor.add(Visit);
                	frame.add(Visitor);
                }
                
                else if(username.equals("employee") && password.equals("employee")){
                	JOptionPane.showMessageDialog(null, "Logged in successfully!");
                	loginPanel.setVisible(false);
                	Emp.setVisible(true);
                	Emp.add(addEmployeeButton);
                	Emp.add(displayEmployeesbtn);
                	Emp.add(addStaffButton);
                	Emp.add(displayStaffbtn);
                	Emp.add(back);
                	Emp.add(EMP);
                	frame.add(Emp);
                }
                
                else {
                    JOptionPane.showMessageDialog(null, "Logged in Failed!\nUsername or Password is Inncorrect.");
                }
            }
        });
        
        File_DataBase.saveVisitors(visitors);
        File_DataBase.saveEmployees(employees);
        File_DataBase.saveStaff(staffMembers);
        File_DataBase.saveAnimals(animals);
              
        frame.setVisible(true);
    }
    
    private static void addVisitor() {
        try {
            String name;
            do {
                name = JOptionPane.showInputDialog("Enter Visitor Name:");
                if (name == null || name.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please Enter a name");
                }
            } while (name == null || name.trim().isEmpty());

            int age = Integer.parseInt(JOptionPane.showInputDialog("Enter Visitor Age:"));

            String ticketIn;
            Ticket ticket;
            do {
                ticketIn = JOptionPane.showInputDialog("Enter Gender (Adult/Child):");
                if (!ticketIn.equalsIgnoreCase("Adult") && !ticketIn.equalsIgnoreCase("Child")) {
                    JOptionPane.showMessageDialog(null, "Invalid gender. Please enter 'Adult' or 'Child'.");
                }
            } while (!ticketIn.equalsIgnoreCase("Adult") && !ticketIn.equalsIgnoreCase("Child"));

            ticket = Ticket.valueOf(ticketIn.toUpperCase());

            visitors.add(new Visitor(name, age, ticket));
            JOptionPane.showMessageDialog(null, "Visitor added successfully!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter numeric values for age.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage());
        }
    }


    private static void addEmployee() {
        try {
            String name = JOptionPane.showInputDialog("Enter Employee Name:");

            int age;
            do {
                age = Integer.parseInt(JOptionPane.showInputDialog("Enter Employee Age:"));
                if (age <= 18 || age >= 70) {
                    JOptionPane.showMessageDialog(null, "Age must be greater than 18.");
                }
            } while (age <= 18 || age >= 70);

            String position = JOptionPane.showInputDialog("Enter Position:");

            double salary;
            do {
                salary = Double.parseDouble(JOptionPane.showInputDialog("Enter Salary:"));
                if (salary <= 2000) {
                    JOptionPane.showMessageDialog(null, "Salary must be at least 2000.");
                }
            } while (salary <= 2000);

            String phoneNumber = JOptionPane.showInputDialog("Enter Phone Number:");

            String genderInput;
            Gender gender;
            do {
                genderInput = JOptionPane.showInputDialog("Enter Gender (Male/Female):");
                if (!genderInput.equalsIgnoreCase("Male") && !genderInput.equalsIgnoreCase("Female")) {
                    JOptionPane.showMessageDialog(null, "Invalid gender. Please enter 'Male' or 'Female'.");
                }
            } while (!genderInput.equalsIgnoreCase("Male") && !genderInput.equalsIgnoreCase("Female"));

            gender = Gender.valueOf(genderInput.toUpperCase());

            employees.add(new Employee(name, age, position, salary, phoneNumber, gender));
            JOptionPane.showMessageDialog(null, "Employee added successfully!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage());
        }
    }


    private static void addStaff() {
    	try {
        String name = JOptionPane.showInputDialog("Enter Staff Name:");
        int age = Integer.parseInt(JOptionPane.showInputDialog("Enter Staff Age:"));
        String position = JOptionPane.showInputDialog("Enter Position:");
        double salary = Double.parseDouble(JOptionPane.showInputDialog("Enter Salary:"));
        String phoneNumber = JOptionPane.showInputDialog("Enter Phone Number:");
        String department = JOptionPane.showInputDialog("Enter Department Name:");
        String genderInput = JOptionPane.showInputDialog("Enter Gender (Male/Female):");
        Gender gender = Gender.valueOf(genderInput.toUpperCase());

        staffMembers.add(new Staff(name, age, position, salary, phoneNumber, department,gender));
        JOptionPane.showMessageDialog(null, "Staff added successfully!");
    } catch(Exception e1) {
		IOException s = new IOException (" ");
		if( e1.equals(s)) {
			
			System.out.println("Invalid input");
		}
	}
}

    private static void addAnimal() {
    	try {
        String name = JOptionPane.showInputDialog("Enter Animal Name:");
        String estPopInput = JOptionPane.showInputDialog("Enter The Animal Estimated Population:");
        int estPop = Integer.parseInt(estPopInput);
        String animalInput = JOptionPane.showInputDialog("Enter The Animal Type (Mammals, Birds, Reptiles, Amphibians, Fish, Invertebrates):");
        AnimalType animal = AnimalType.valueOf(animalInput.toUpperCase());
        String regionIn = JOptionPane.showInputDialog("Enter Animal Status (NORTH_AMERICA, SOUTH_AMERICA, EUROPE, ASIA, AFRICA, AUSTRALIA, ANTARCTICA):");
        Region region = Region.valueOf(regionIn.toUpperCase());
        String habitatInput = JOptionPane.showInputDialog("Enter Habitat Type (SAVANNAH, FOREST, AQUATIC, MOUNTAIN, GRASSLAND):");
        HabitatType habitatType = HabitatType.valueOf(habitatInput.toUpperCase());
        String dietInput = JOptionPane.showInputDialog("Enter The Animal Diet (Omnivorus , Carnivorus , Herbevorus):");
        Diet diet = Diet.valueOf(dietInput.toUpperCase());
        String statInput = JOptionPane.showInputDialog("Enter Animal Status (Endagered/Safe):");
        Stats stat = Stats.valueOf(statInput.toUpperCase());
        String genderInput = JOptionPane.showInputDialog("Enter Animal Gender (Male/Female):");
        Gender gender = Gender.valueOf(genderInput.toUpperCase());

		animals.add(new Animal( name, estPop, animal, region, habitatType, diet,  stat, gender));
        JOptionPane.showMessageDialog(null, "Animal added successfully!");  
    } catch(Exception e1) {
		IOException s = new IOException (" ");
		if( e1.equals(s)) {
			
			System.out.println("Invalid input");
		}
	}
}

    private static <T> void displayData(ArrayList<T> data, String title) {
        StringBuilder sb = new StringBuilder();
        for (T item : data) {
            sb.append(item).append("\n");
        }
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(600, 200));

        JOptionPane.showMessageDialog(null, scrollPane, title, JOptionPane.INFORMATION_MESSAGE);
    }
}