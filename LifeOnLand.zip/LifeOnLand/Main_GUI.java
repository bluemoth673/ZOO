package LifeOnLand;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

public class Main_GUI {

    private static ArrayList<Visitor> visitors = File_DataBase.loadVisitors();
    private static ArrayList<Employee> employees = File_DataBase.loadEmployees();
    private static ArrayList<Staff> staffMembers = File_DataBase.loadStaff();
    private static ArrayList<Animal> animals = File_DataBase.loadAnimals();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Zoo Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(2076,2072);
        frame.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 2));

        // Buttons
        JButton addVisitorButton = new JButton("Add Visitor");
        JButton addEmployeeButton = new JButton("Add Employee");
        JButton addStaffButton = new JButton("Add Staff");
        JButton addAnimalButton = new JButton("Add Animal");
        
        JButton displayVisitorsButton = new JButton("Display Visitors");
        JButton displayEmployeesButton = new JButton("Display Employees");
        JButton displayStaffButton = new JButton("Display Staff");
        JButton displayAnimalsButton = new JButton("Display Animals");

        panel.add(addVisitorButton);
        panel.add(addEmployeeButton);
        panel.add(addStaffButton);
        panel.add(addAnimalButton);
        panel.add(displayVisitorsButton);
        panel.add(displayEmployeesButton);
        panel.add(displayStaffButton);
        panel.add(displayAnimalsButton);
        
        frame.add(panel, BorderLayout.CENTER);

        // Action listeners for buttons
        addVisitorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addVisitor();
            }
        });

        addEmployeeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addEmployee();
            }
        });

        addStaffButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addStaff();
            }
        });

        addAnimalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addAnimal();
            }
        });

        displayVisitorsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayVisitors();
            }
        });

        displayEmployeesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayEmployees();
            }
        });

        displayStaffButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayStaff();
            }
        });

        displayAnimalsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayAnimals();
            }
        });

        frame.setVisible(true);
    }

    private static void addVisitor() {
        try {
            String name;
            do {
                name = JOptionPane.showInputDialog("Enter Visitor Name:");
                if (name == null || name.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please Enter a name");
                }
            } while (name == null || name.trim().isEmpty());

            int age = Integer.parseInt(JOptionPane.showInputDialog("Enter Visitor Age:"));

            String ticketIn;
            Ticket ticket;
            do {
                ticketIn = JOptionPane.showInputDialog("Enter Gender (Adult/Child):");
                if (!ticketIn.equalsIgnoreCase("Adult") && !ticketIn.equalsIgnoreCase("Child")) {
                    JOptionPane.showMessageDialog(null, "Invalid gender. Please enter 'Adult' or 'Child'.");
                }
            } while (!ticketIn.equalsIgnoreCase("Adult") && !ticketIn.equalsIgnoreCase("Child"));

            ticket = Ticket.valueOf(ticketIn.toUpperCase());

            visitors.add(new Visitor(name, age, ticket));
            JOptionPane.showMessageDialog(null, "Visitor added successfully!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter numeric values for age.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage());
        }
    }


    private static void addEmployee() {
        try {
            String name = JOptionPane.showInputDialog("Enter Employee Name:");

            int age;
            do {
                age = Integer.parseInt(JOptionPane.showInputDialog("Enter Employee Age:"));
                if (age <= 15) {
                    JOptionPane.showMessageDialog(null, "Age must be greater than 15.");
                }
            } while (age <= 15);

            String position = JOptionPane.showInputDialog("Enter Position:");

            double salary;
            do {
                salary = Double.parseDouble(JOptionPane.showInputDialog("Enter Salary:"));
                if (salary <= 0) {
                    JOptionPane.showMessageDialog(null, "Salary must be a positive number.");
                }
            } while (salary <= 0);

            String phoneNumber = JOptionPane.showInputDialog("Enter Phone Number:");

            String genderInput;
            Gender gender;
            do {
                genderInput = JOptionPane.showInputDialog("Enter Gender (Male/Female):");
                if (!genderInput.equalsIgnoreCase("Male") && !genderInput.equalsIgnoreCase("Female")) {
                    JOptionPane.showMessageDialog(null, "Invalid gender. Please enter 'Male' or 'Female'.");
                }
            } while (!genderInput.equalsIgnoreCase("Male") && !genderInput.equalsIgnoreCase("Female"));

            gender = Gender.valueOf(genderInput.toUpperCase());

            employees.add(new Employee(name, age, position, salary, phoneNumber, gender));
            JOptionPane.showMessageDialog(null, "Employee added successfully!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage());
        }
    }


    private static void addStaff() {
    	try {
        String name = JOptionPane.showInputDialog("Enter Staff Name:");
        int age = Integer.parseInt(JOptionPane.showInputDialog("Enter Staff Age:"));
        String position = JOptionPane.showInputDialog("Enter Position:");
        double salary = Double.parseDouble(JOptionPane.showInputDialog("Enter Salary:"));
        String phoneNumber = JOptionPane.showInputDialog("Enter Phone Number:");
        String department = JOptionPane.showInputDialog("Enter Department Name:");
        String genderInput = JOptionPane.showInputDialog("Enter Gender (Male/Female):");
        Gender gender = Gender.valueOf(genderInput.toUpperCase());

        staffMembers.add(new Staff(name, age, position, salary, phoneNumber, department,gender));
        JOptionPane.showMessageDialog(null, "Staff added successfully!");
    } catch(Exception e1) {
		IOException s = new IOException (" ");
		if( e1.equals(s)) {
			
			System.out.println("Invalid input");
		}
	}
	}

    private static void addAnimal() {
    	try {
        String name = JOptionPane.showInputDialog("Enter Animal Name:");
        String habitatInput = JOptionPane.showInputDialog("Enter Habitat Type (SAVANNAH, FOREST, AQUATIC, MOUNTAIN, GRASSLAND):");
        HabitatType habitatType = HabitatType.valueOf(habitatInput.toUpperCase());
        String estPopInput = JOptionPane.showInputDialog("Enter The Animal Estimated Population:");
        int estPop = Integer.parseInt(estPopInput);
        String animalInput = JOptionPane.showInputDialog("Enter The Animal Type (Mammals, Birds, Reptiles, Amphibians, Fish, Invertebrates):");
        AnimalType animal = AnimalType.valueOf(animalInput.toUpperCase());
        String dietInput = JOptionPane.showInputDialog("Enter The Animal Type (Mammals, Birds, Reptiles, Amphibians, Fish, Invertebrates):");
        Diet diet = Diet.valueOf(dietInput.toUpperCase());
        String genderInput = JOptionPane.showInputDialog("Enter Animal Gender (Male/Female):");
        Gender gender = Gender.valueOf(genderInput.toUpperCase());
        String statIn = JOptionPane.showInputDialog("Enter Animal Status (Endagered/Safe):");
        Stats stat = Stats.valueOf(statIn.toUpperCase());
        String regionIn = JOptionPane.showInputDialog("Enter Animal Status (NORTH_AMERICA, SOUTH_AMERICA, EUROPE, ASIA, AFRICA, AUSTRALIA, ANTARCTICA):");
        Region region = Region.valueOf(regionIn.toUpperCase());

		animals.add(new Animal( name, estPop, animal, region, habitatType, diet, stat, gender));
        JOptionPane.showMessageDialog(null, "Animal added successfully!");  
    } catch(Exception e1) {
		IOException s = new IOException (" ");
		if( e1.equals(s)) {
			
			System.out.println("Invalid input");
		}
	}
}

    
    private static void displayVisitors() {
        StringBuilder sb = new StringBuilder();
        for (Visitor v : visitors) {
            sb.append(v).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void displayEmployees() {
        StringBuilder sb = new StringBuilder();
        for (Employee e : employees) {
            sb.append(e).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void displayStaff() {
        StringBuilder sb = new StringBuilder();
        for (Staff s : staffMembers) {
            sb.append(s).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void displayAnimals() {
        StringBuilder sb = new StringBuilder();
        for (Animal a : animals) {
            sb.append(a).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}