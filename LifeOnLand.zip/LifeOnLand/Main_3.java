package LifeOnLand;

import java.util.ArrayList;
import java.util.Scanner;

public class Main_3 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Load data from files
        ArrayList<Visitor> visitors = File_DataBase.loadVisitors();
        ArrayList<Employee> employees = File_DataBase.loadEmployees();
        ArrayList<Staff> staffMembers = File_DataBase.loadStaff();
        ArrayList<Animal> animals = File_DataBase.loadAnimals();

        boolean running = true;

        while (running) {
            // Menu for user input
            System.out.println("\nMenu:");
            System.out.println("1. Add Visitor");
            System.out.println("2. Add Employee");
            System.out.println("3. Add Staff");
            System.out.println("4. Add Animal");
            System.out.println("5. Delete Visitor");
            System.out.println("6. Delete Employee");
            System.out.println("7. Delete Staff");
            System.out.println("8. Delete Animal");
            System.out.println("9. Display All Visitors");
            System.out.println("10. Display All Employees");
            System.out.println("11. Display All Staff");
            System.out.println("12. Display All Animals");
            System.out.println("0. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
            case 1: // Add Visitor
                System.out.print("Enter Visitor Name: ");
                String visitorName = scanner.nextLine();

                System.out.print("Enter Visitor Age: ");
                if (!scanner.hasNextInt()) {
                    System.out.println("Invalid age. Please enter a numeric value.");
                    scanner.nextLine(); 
                    break;
                }
                int visitorAge = scanner.nextInt();
                scanner.nextLine(); 

                Ticket ticket = null;
                while (ticket == null) {
                    System.out.print("Enter Gender (Adult/Child): ");
                    String ticketInput = scanner.nextLine().trim().toUpperCase();

                    if (ticketInput.equals("ADULT") || ticketInput.equals("CHILD")) {
                    	ticket = Ticket.valueOf(ticketInput);
                    } else {
                        System.out.println("Invalid input. Please enter 'Adult' or 'Child'.");
                    }
                }

                visitors.add(new Visitor(visitorName, visitorAge, ticket));
                break;
            case 2: // Add Employee
                try {
                    System.out.print("Enter Employee Name: ");
                    String employeeName = scanner.nextLine();

                    System.out.print("Enter Employee Age: ");
                    int employeeAge = scanner.nextInt();
                    scanner.nextLine(); 

                    System.out.print("Enter Position: ");
                    String position = scanner.nextLine();
                    if (!position.matches("[a-zA-Z ]+")) {
                        throw new IllegalArgumentException("Position must contain only letters.");
                    }

                    System.out.print("Enter Salary: ");
                    double salary = scanner.nextDouble();
                    scanner.nextLine(); 

                    System.out.print("Enter Phone Number: ");
                    String employeePhoneNumber = scanner.nextLine();

                    Gender employeeGender = null;
                    while (employeeGender == null) {
                        System.out.print("Enter Gender (Male/Female): ");
                        String genderInput = scanner.nextLine().trim().toUpperCase();

                        if (genderInput.equals("MALE") || genderInput.equals("FEMALE")) {
                            employeeGender = Gender.valueOf(genderInput);
                        } else {
                            System.out.println("Invalid input. Please enter 'Male' or 'Female'.");
                        }
                    }

                    employees.add(new Employee(employeeName, employeeAge, position, salary, employeePhoneNumber, employeeGender));
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Age must be a numeric value.");
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid input: " + e.getMessage());
                }
                break;


                case 3: // Add Staff
                    try {
                        System.out.print("Enter Staff Name: ");
                        String staffName = scanner.nextLine();

                        System.out.print("Enter Staff Age: ");
                        int staffAge = scanner.nextInt();

                        System.out.print("Enter Position: ");
                        String staffPosition = scanner.nextLine();
                        if (!staffPosition.matches("[a-zA-Z ]+")) {
                            throw new IllegalArgumentException("Position must contain only letters.");
                        }

                        System.out.print("Enter Salary: ");
                        double staffSalary = scanner.nextDouble();
                        
                        System.out.print("Enter PhoneNumber: ");
                        String SaffphoneNumber = scanner.nextLine();
                        
                        System.out.print("Enter Department Name: ");
                        String Staffdepartment = scanner.nextLine();
                        
                        Gender staffGender = null;
                        while (staffGender == null) {
                            System.out.print("Enter Gender (Male/Female): ");
                            String genderInput = scanner.nextLine().trim().toUpperCase(); 
                            

                            if (genderInput.equals("MALE") || genderInput.equals("FEMALE")) {
                                staffGender = Gender.valueOf(genderInput); 
                            } else {
                                System.out.println("Invalid input. Please enter 'Male' or 'Female'.");
                            }
                        }
                        staffMembers.add(new Staff(staffName, staffAge, staffPosition, staffSalary, SaffphoneNumber, Staffdepartment,staffGender));
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Age must be a numeric value.");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Invalid input: " + e.getMessage());
                    }
                    break;


                case 4: // Add Animal
                    try {
                        System.out.print("Enter Animal Name: ");
                        String animalName = scanner.nextLine();
                        HabitatType habitatType = null;
                        while (habitatType == null) {
                        	System.out.print("Enter Habitat Type (SAVANNAH, FOREST, AQUATIC, MOUNTAIN, GRASSLAND): ");
                            String habitat = scanner.nextLine().trim().toUpperCase(); 

                            if (habitat.equals("SAVANNAH") || habitat.equals("FOREST") || habitat.equals("AQUATIC")
                            		|| habitat.equals("MOUNTAIN") || habitat.equals("GRASSLAND") || habitat.equals("S")
                            		|| habitat.equals("F") || habitat.equals("A") || habitat.equals("M") || habitat.equals("G")) {
                            	habitatType  = HabitatType.valueOf(habitat); 
                            } else {
                                System.out.println("Invalid input. Please enter 'SAVANNAH', 'FOREST', 'AQUATIC', 'MOUNTAIN' or 'GRASSLAND'.");
                            }
                        }
                        System.out.print("Enter Animal Estimated Population: ");
                        int estPop = scanner.nextInt();
                        AnimalType animal = null;
                        while (animal == null) {
                        	System.out.print("Enter The Animal Type (Mammals, Birds, Reptiles, Amphibians, Fish, Invertebrates): ");
                            String Type = scanner.nextLine().trim().toUpperCase(); 

                            if (Type.equals("Mammals") || Type.equals("Birds") || Type.equals("Reptiles")
                            		|| Type.equals("Amphibians") || Type.equals("Fish") || Type.equals("Invertebrates")
                            		|| Type.equals("M") || Type.equals("B") || Type.equals("R") || Type.equals("A")
                            		|| Type.equals("F") || Type.equals("I")) {
                            	animal  = AnimalType.valueOf(Type); 
                            } else {
                                System.out.println("Invalid input. Please enter 'Mammals', 'Birds', 'Reptiles', 'Amphibians', 'Invertebrates'"
                                		+ " or 'Fish'.");
                            }
                        }
                        Diet diet = null;
                        while (diet == null) {
                        	System.out.print("Enter The Animal Diet (Omnivorus , Carnivorus , Herbevorus): ");
                            String d = scanner.nextLine().trim().toUpperCase(); 

                            if (d.equals("Omnivorus") || d.equals("Carnivorus") || d.equals("Herbevorus")
                            		|| d.equals("O") || d.equals("C") || d.equals("H")) {
                            	diet  =  Diet.valueOf(d); 
                            } else {
                                System.out.println("Invalid input. Please enter 'Omnivorus', 'Carnivorus' or 'Herbevorus'.");
                            }
                        }
                        Gender animalGender = null;                   
                        while (animalGender == null) {
                            System.out.print("Enter Gender (Male/Female): ");
                            String genderInput = scanner.nextLine().trim().toUpperCase(); 
                            

                            if (genderInput.equals("MALE") || genderInput.equals("FEMALE")) {
                            	animalGender  = Gender.valueOf(genderInput); 
                            } else {
                                System.out.println("Invalid input. Please enter 'Male' or 'Female'.");
                            }
                        }
                        Stats animalStat = null;                   
                        while (animalStat == null) {
                            System.out.print("Enter Animal Status (Endagered/Safe): ");
                            String Stat = scanner.nextLine().trim().toUpperCase(); 
                            

                            if (Stat.equals("MALE") || Stat.equals("FEMALE")) {
                            	animalStat  = Stats.valueOf(Stat); 
                            } else {
                                System.out.println("Invalid input. Please enter 'Male' or 'Female'.");
                            }
                        }
                        Region region = null;
                        while (region == null) {
                        	System.out.print("Enter Animal Status (NORTH_AMERICA, SOUTH_AMERICA, EUROPE, ASIA, AFRICA, AUSTRALIA, ANTARCTICA): ");
                            String animalRegion = scanner.nextLine().trim().toUpperCase(); 
                            

                            if (animalRegion.equals("MALE") || animalRegion.equals("FEMALE")) {
                            	region  = Region.valueOf(animalRegion);
                        }
                        }

						animals.add(new Animal( animalName, estPop, animal, region, habitatType, diet, animalStat, animalGender));
                    }catch (IllegalArgumentException e) {
                        System.out.println("Invalid input: " + e.getMessage());
                    }
                    break;

                case 5: // Delete Visitor
                    System.out.print("Enter Visitor Name to delete: ");
                    String visitorToDelete = scanner.nextLine();
                    visitors.removeIf(visitor -> visitor.getName().equalsIgnoreCase(visitorToDelete));
                    break;

                case 6: // Delete Employee
                    System.out.print("Enter Employee Name to delete: ");
                    String employeeToDelete = scanner.nextLine();
                    employees.removeIf(employee -> employee.getName().equalsIgnoreCase(employeeToDelete));
                    break;

                case 7: // Delete Staff
                    System.out.print("Enter Staff Name to delete: ");
                    String staffToDelete = scanner.nextLine();
                    staffMembers.removeIf(staff -> staff.getName().equalsIgnoreCase(staffToDelete));
                    break;

                case 8: // Delete Animal
                    System.out.print("Enter Animal Name to delete: ");
                    String animalToDelete = scanner.nextLine();
                    animals.removeIf(animal -> animal.getName().equalsIgnoreCase(animalToDelete));
                    break;

                case 9: // Display Visitors
                    System.out.println("Visitors:");
                    visitors.forEach(System.out::println);
                    break;

                case 10: // Display Employees
                    System.out.println("Employees:");
                    employees.forEach(System.out::println);
                    break;

                case 11: // Display Staff
                    System.out.println("Staff:");
                    staffMembers.forEach(System.out::println);
                    break;

                case 12: // Display Animals
                    System.out.println("Animals:");
                    animals.forEach(System.out::println);
                    break;

                case 0: // Exit
                    running = false;
                    System.out.println("Exiting program. \nGoodbye!👋🏼");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        
        File_DataBase.saveVisitors(visitors);
        File_DataBase.saveEmployees(employees);
        File_DataBase.saveStaff(staffMembers);
        File_DataBase.saveAnimals(animals);

        scanner.close();
    }
}
