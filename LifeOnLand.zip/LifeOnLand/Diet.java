package LifeOnLand;

public enum Diet { Omnivorus , Carnivorus , Herbevorus}