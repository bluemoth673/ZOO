package LifeOnLand;

public class Animal {
    private String name;
    private HabitatType habitat; 
    private int estPop; 
    private AnimalType animal;
    private Diet diet;
    private Gender gender; 
    private Stats stats;
    private Region region;

    // Constructor
    public Animal(String name, int estPop, AnimalType animal, Region region, 
    		HabitatType habitat, Diet diet, Stats stats, Gender gender) {
		this.name = name;
		name = " ";
		this.estPop = estPop;
		this.animal = animal;
		this.region = region;
		this.habitat = habitat;
		this.diet = diet;
		this.stats = stats;
		this.gender = gender;
	}

	// Setters & Getters
    public String getName() {
        return name;
    }
	public void setName(String name) {
        this.name = name;
    }

    public HabitatType getHabitat() {
        return habitat; 
    }

    public void setHabitat(HabitatType habitat) {
        this.habitat = habitat;
    }

    public int getEstPop() {
        return estPop;
    }

    public void setEstPop(int estPop) {
        this.estPop = estPop;
    }

    public AnimalType getAnimal() {
		return animal;
	}

	public void setAnimal(AnimalType animal) {
		this.animal = animal;
	}

	public Diet getDiet() {
		return diet;
	}

	public void setDiet(Diet diet) {
		this.diet = diet;
	}

	public Gender getGender() {
        return gender;
    }

    public Stats getStats() {
		return stats;
	}

	public void setStats(Stats stats) {
		this.stats = stats;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	@Override
    public String toString() {
        return "Name: " + name + " ,estPop: " + estPop + " ,AnimalType: " + animal + " ,Region " + region +
        		" ,habitat: " + habitat + " ,Diet: " + diet + " ,Status: " + stats + " ,gender: " + gender ;
    }
    public static Animal fromString(String line) {
        String[] parts = line.split(" ");
        if (parts.length == 15) {
            String name = parts[1];
            int estPop = Integer.parseInt(parts[3]);
            AnimalType animal = AnimalType.valueOf(parts[5]);
            Region region = Region.valueOf(parts[7]);
            HabitatType habitatType = HabitatType.valueOf(parts[9]);
            Diet diet = Diet.valueOf(parts[11]);
            Stats stat = Stats.valueOf(parts[13]);
            Gender gender = Gender.valueOf(parts[15]);
            return new Animal(name, estPop, animal, region, habitatType, diet, stat, gender);
        }
        return null;
    }
}