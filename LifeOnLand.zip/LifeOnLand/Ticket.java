package LifeOnLand;

public enum Ticket { Adult, Child}