package LifeOnLand;

public enum AnimalType { Mammals, Birds, Reptiles, Amphibians, Fish, Invertebrates}