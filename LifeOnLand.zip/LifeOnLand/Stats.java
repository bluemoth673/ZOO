package LifeOnLand;

public enum Stats { Endangered , Safe }