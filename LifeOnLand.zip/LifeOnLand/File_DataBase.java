package LifeOnLand;

import java.io.*;
import java.util.ArrayList;

public class File_DataBase {

    
    private static final String BASE_DIR = "D:\\University\\AASTMT\\3rd Term\\Object Oriented Programming (OOP)\\Project\\Life on Land\\src\\LifeOnLand";

   
    private static final String ANIMAL_FILE = BASE_DIR + "\\animal.txt";
    private static final String EMPLOYEE_FILE = BASE_DIR + "\\employee.txt";
    private static final String STAFF_FILE = BASE_DIR + "\\staff.txt";
    private static final String VISITOR_FILE = BASE_DIR + "\\visitor.txt";

    
    static {
        new File(BASE_DIR).mkdirs();
    }


    public static <T> void saveToFile(String fileName, ArrayList<T> list) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (T item : list) {
                writer.write(item.toString());
                writer.newLine();
            }
            System.out.println("Data saved to " + fileName);
        } catch (IOException e) {
            System.out.println("Error saving data to " + fileName + ": " + e.getMessage());
        }
    }

    
    public static <T> ArrayList<T> loadFromFile(String fileName, LineParser<T> parser) {
        ArrayList<T> list = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                T item = parser.parse(line);
                if (item != null) {
                    list.add(item);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(fileName + " not found. A new file will be created when data is saved.");
        } catch (IOException e) {
            System.out.println("Error loading data from " + fileName + ": " + e.getMessage());
        }
        return list;
    }

  
    public static void saveAnimals(ArrayList<Animal> animals) {
        saveToFile(ANIMAL_FILE, animals);
    }

    public static void saveEmployees(ArrayList<Employee> employees) {
        saveToFile(EMPLOYEE_FILE, employees);
    }

    public static void saveStaff(ArrayList<Staff> staffMembers) {
        saveToFile(STAFF_FILE, staffMembers);
    }

    public static void saveVisitors(ArrayList<Visitor> visitors) {
        saveToFile(VISITOR_FILE, visitors);
    }

   
    public static ArrayList<Animal> loadAnimals() {
        return loadFromFile(ANIMAL_FILE, Animal::fromString);
    }

    public static ArrayList<Employee> loadEmployees() {
        return loadFromFile(EMPLOYEE_FILE, Employee::fromString);
    }

    public static ArrayList<Staff> loadStaff() {
        return loadFromFile(STAFF_FILE, Staff::fromString);
    }

    public static ArrayList<Visitor> loadVisitors() {
        return loadFromFile(VISITOR_FILE, Visitor::fromString);
    }

    
    public interface LineParser<T> {
        T parse(String line);
    }
}
