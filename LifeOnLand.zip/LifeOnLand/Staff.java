package LifeOnLand;
public class Staff extends Employee {
    protected String department;
//constructor
    public Staff(String name, int age, String position, double salary, String phoneNumber, String department,Gender gender) {
        super(name, age, position, salary, phoneNumber, gender);
        this.department = department;
    }
    
// setters and getters
    public String getDepartment() {
        return department;
    }

    @Override
    public String info() {
        return super.info() + " ,Department: " + department;
    }
    public static Staff fromString(String line) {
        String[] parts = line.split(" ");
        if (parts.length == 14) {
            String name = parts[1];
            int age = Integer.parseInt(parts[3]);
            String position = parts[5];
            double salary = Double.parseDouble(parts[7]);
            String staffPhoneNumber = parts[9];
            String department = parts[11];
            Gender gender = Gender.valueOf(parts[13]);
            return new Staff(name, age, position, salary, staffPhoneNumber, department, gender);
        }
        return null;
    }
}