package LifeOnLand;

import javax.swing.*;
import java.awt.*;

public class code {
    private JFrame frame;
    private JButton openSecondGUIButton;

    @SuppressWarnings("unused")
	public code() {
        frame = new JFrame("Main GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        openSecondGUIButton = new JButton("Open Second GUI");
        openSecondGUIButton.addActionListener(e -> {
            // Pass this MainGUI instance to SecondGUI
            SecondGUI secondGUI = new SecondGUI(this);
            secondGUI.show();
        });

        frame.setLayout(new FlowLayout());
        frame.add(openSecondGUIButton);

        frame.setVisible(true);
    }

    // Example method to update the Main GUI from Second GUI
    public void updateMainGUI(String message) {
        JOptionPane.showMessageDialog(frame, message);
    }

    public static void main(String[] args) {
        new code();
    }
}

class SecondGUI {
    private JFrame frame;
    private JButton updateMainGUIButton;
    @SuppressWarnings("unused")
	private code code; // Reference to Main GUI

    @SuppressWarnings("unused")
	public SecondGUI(code mainGUI) {
        this.code = mainGUI; // Store the reference

        frame = new JFrame("Second GUI");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(300, 200);

        updateMainGUIButton = new JButton("Send Message to Main GUI");
        updateMainGUIButton.addActionListener(e -> mainGUI.updateMainGUI("Hello from Second GUI!"));

        frame.setLayout(new FlowLayout());
        frame.add(updateMainGUIButton);
    }

    public void show() {
        frame.setVisible(true);
    }
}