package LifeOnLand;
public class Visitor extends Person {
    private Ticket ticketType;
//constructor
    public Visitor(String name, int age, Ticket ticketType) {
        super(name, age);
        this.ticketType = ticketType;
    }
// setters and getters


    @Override
    public String info() {
        return super.info() + " ,Ticket Type: " + ticketType;
    }
    public static Visitor fromString(String line) {
        String[] parts = line.split(" ");
        if (parts.length == 5) {
            String name = parts[1];
            int age = Integer.parseInt(parts[3]);
            Ticket ticketType = Ticket.valueOf(parts[5]);
            return new Visitor(name, age, ticketType);
        }else {
        	System.out.println("Please enter  name , age, TicketType");
        }
        return null;
    }
    @Override
    public String toString() {
        return "Name: " + name + " ,Age: " + age + " ,TicketType: " + ticketType ;
    }

}