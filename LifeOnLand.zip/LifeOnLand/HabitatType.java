package LifeOnLand;

public enum HabitatType { SAVANNAH, FOREST, DESERT, AQUATIC, MOUNTAIN, GRASSLAND }