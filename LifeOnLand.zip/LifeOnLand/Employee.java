package LifeOnLand;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Employee extends Person {
    protected String position;
    protected double salary;
    protected String phoneNumber;
    protected Gender gender;
    protected String username;
    protected String password;
    
//constructor
    
    public Employee(String name, int age, String position, double salary, String phoneNumber,Gender gender) {
        super(name, age);
        this.position = position;
        this.salary = salary;
        this.phoneNumber = phoneNumber;
        this.gender=gender;
    }

	// setters and getters
    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public String toString() {
        return "name " + name + " ,Age: " + age + " ,Position: " + position + " ,Salary: " + salary + 
                " ,PhoneNumber: " + phoneNumber + " ,Gender: " + gender ;
    }
    public static Employee fromString(String line) {
        try {          
            line = line.trim(); 

            String[] parts = line.split(" "); 
            if(parts.length != 11) return null;
            String name = parts[1].trim();
            int age = Integer.parseInt(parts[3].trim()); 
            String position = parts[5].trim();
            double salary = Double.parseDouble(parts[7].trim());
            String phoneNumber = parts[9].trim();
            Gender gender = Gender.valueOf(parts[11].trim().toUpperCase());

            return new Employee(name, age, position, salary, phoneNumber, gender);
        } catch (Exception e) {
            System.out.println("Error" + line);
        //  e.printStackTrace();
            return null; 
        }
    }
    public static ArrayList<Employee> loadEmployees() {
        ArrayList<Employee> employees = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("employees.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                Employee employee = Employee.fromString(line);
                employees.add(employee);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return employees;
    }

}